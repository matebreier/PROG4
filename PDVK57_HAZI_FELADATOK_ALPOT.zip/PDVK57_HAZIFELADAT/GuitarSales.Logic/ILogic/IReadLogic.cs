﻿using GuitarSales.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuitarSales.Logic.ILogic
{
    public interface IReadLogic
    {
        Costumer GetOneCostumer(int id);
        IList<Costumer> GetAllCostumers();
        Product GetOneProduct(int id);
        IList<Product> GetAllProducts();
        Purchase GetOnePurchase(int id);
        IList<Purchase> GetAllPurchases();
        Country GetOneCountry(int id);
        IList<Country> GetAllCountry();
    }
}
