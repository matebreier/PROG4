﻿using GuitarSales.Logic.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuitarSales.Logic.ILogic
{
    public interface IReportLogic
    {
        IList<AVGRatingInCountries> GetAVGRatingInCountry();

        IList<CountPurchasesPerCustomer> GetPurchasesPerCustomer();
    }
}
