﻿using GuitarSales.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuitarSales.Logic.ILogic
{
    public interface IAdminLogic
    {
        void InsertCostumer(Costumer costumer);
        void InsertProduct(Product product);
        void InsertPurchase(Purchase purchase);
        void InsertCountry(Country country);

        void DeleteCostumer(Costumer costumer);
        void DeleteProduct(Product product);
        void DeletePurchase(Purchase purchase);
        void DeleteCountry(Country country);

        void UpdateCostumer(Costumer costumer);
        void UpdateProduct(Product product);
        void UpdatePurchase(Purchase purchase);
        void UpdateCountry(Country country);
    }
}
