﻿using GuitarSales.Logic.ILogic;
using GuitarSales.Models;
using GuitarSales.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuitarSales.Logic.Logic
{
    public class AdminLogic : IAdminLogic
    {
        private ICostumerRepository costumerRepo;
        private IProductRepository productRepo;
        private IPurchaseRepository purchaseRepo;
        private ICountryRepository countryRepo;

        public AdminLogic(ICostumerRepository costumerRepo, IProductRepository productRepo, IPurchaseRepository purchaseRepo, ICountryRepository countryRepo)
        {
            this.costumerRepo = costumerRepo;
            this.productRepo = productRepo;
            this.purchaseRepo = purchaseRepo;
            this.countryRepo = countryRepo;
        }

        /*
         * INSERT
         */

        public void InsertCostumer(Costumer costumer)
        {
            this.costumerRepo.Insert(costumer);
        }
        public void InsertProduct(Product product)
        {
            this.productRepo.Insert(product);
        }
        public void InsertPurchase(Purchase purchase)
        {
            this.purchaseRepo.Insert(purchase);
        }
        public void InsertCountry(Country country)
        {
            this.countryRepo.Insert(country);

        }

        /*
         * DELETE
         */

        public void DeleteCostumer(Costumer costumer)
        {
            this.costumerRepo.Delete(costumer);
        }
        public void DeleteProduct(Product product)
        {
            this.productRepo.Delete(product);
        }
        public void DeletePurchase(Purchase purchase)
        {
            this.purchaseRepo.Delete(purchase);
        }
        public void DeleteCountry(Country country)
        {
            this.countryRepo.Delete(country);
        }

        /*
         * UPDATE
         */

        public void UpdateCostumer(Costumer costumer)
        {
            this.costumerRepo.Update(costumer);
        }
        public void UpdateProduct(Product product)
        {
            this.productRepo.Update(product);
        }
        public void UpdatePurchase(Purchase purchase)
        {
            this.purchaseRepo.Update(purchase);
        }
        public void UpdateCountry(Country country)
        {
            this.countryRepo.Update(country);
        }
    }
}
