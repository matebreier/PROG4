﻿using GuitarSales.Logic.ILogic;
using GuitarSales.Models;
using GuitarSales.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuitarSales.Logic.Logic
{
    public class ReadLogic : IReadLogic
    {
        private ICostumerRepository costumerRepo;
        private IProductRepository productRepo;
        private IPurchaseRepository purchaseRepo;
        private ICountryRepository countryRepo;

        public ReadLogic(ICostumerRepository costumerRepo, IProductRepository productRepo, IPurchaseRepository purchaseRepo, ICountryRepository countryRepo)
        {
            this.costumerRepo = costumerRepo;
            this.productRepo = productRepo;
            this.purchaseRepo = purchaseRepo;
            this.countryRepo = countryRepo;
        }

        public IList<Costumer> GetAllCostumers()
        {
            return this.costumerRepo.GetAll().ToList();
        }

        public IList<Country> GetAllCountry()
        {
            return this.countryRepo.GetAll().ToList();
        }

        public IList<Product> GetAllProducts()
        {
            return this.productRepo.GetAll().ToList();
        }

        public IList<Purchase> GetAllPurchases()
        {
            return this.purchaseRepo.GetAll().ToList();
        }

        public Costumer GetOneCostumer(int id)
        {
            return this.costumerRepo.GetOne(id);
        }

        public Country GetOneCountry(int id)
        {
            return this.countryRepo.GetOne(id);
        }

        public Product GetOneProduct(int id)
        {
            return this.productRepo.GetOne(id);
        }

        public Purchase GetOnePurchase(int id)
        {
            return this.purchaseRepo.GetOne(id);
        }
    }
}
