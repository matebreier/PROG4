﻿using GuitarSales.Logic.ILogic;
using GuitarSales.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuitarSales.Logic.Logic
{
    public class ReportLogic : IReportLogic
    {
        private ICostumerRepository costumerRepo;
        private IProductRepository productRepo;
        private ICountryRepository countryRepo;
        private IPurchaseRepository purchaseRepo;

        public ReportLogic(ICostumerRepository costumerRepo, IProductRepository productRepo, ICountryRepository countryRepo, IPurchaseRepository purchaseRepo)
        {
            this.costumerRepo = costumerRepo;
            this.productRepo = productRepo;
            this.countryRepo = countryRepo;
            this.purchaseRepo = purchaseRepo;           
        }

        public IList<AVGRatingInCountries> GetAVGRatingInCountry()
        {
            var query = from product in this.productRepo.GetAll()
                        group product by new { product.CountryId, product.Country.Name } into productgrp
                        select new AVGRatingInCountries { Country = productgrp.Key.Name, AVGRating = productgrp.Average(x => x.Rating) };
            return query.ToList();
        }

        public IList<CountPurchasesPerCustomer> GetPurchasesPerCustomer()
        {
            var query = from purchase in this.purchaseRepo.GetAll()
                        group purchase by new { purchase.CostumerId, purchase.Costumer.Name } into purchasegrp
                        select new CountPurchasesPerCustomer { CostumerName = purchasegrp.Key.Name, PurchasesCounter = purchasegrp.Count() };
            return query.ToList();
        }
    }
}
