﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuitarSales.Logic.Logic
{
    public class AVGRatingInCountries
    {
        public double AVGRating { get; set; }

        public string Country { get; set; }

        public override bool Equals(object obj)
        {
            if (obj is AVGRatingInCountries)
            {
                AVGRatingInCountries other = obj as AVGRatingInCountries;

                return this.Country == other.Country && this.AVGRating == other.AVGRating;
            }
            else
            {
                return false;
            }
        }

        public override int GetHashCode()
        {
            return this.Country.GetHashCode();
        }

        public override string ToString()
        {
            return $"In {this.Country}: {this.AVGRating}";
        }
    }
}
