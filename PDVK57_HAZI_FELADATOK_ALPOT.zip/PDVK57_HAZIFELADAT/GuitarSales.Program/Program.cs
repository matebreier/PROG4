﻿using GuitarSales.Logic.ILogic;
using GuitarSales.Logic.Logic;
using GuitarSales.Models;
using GuitarSales.Repository.Classes;
using GuitarSales.Repository.Interfaces;
using System;

namespace GuitarSales.Program
{
    class Program
    {
        static void Main(string[] args)
        {
            DataBaseContext ctx = new DataBaseContext();
            IMainRepository<Costumer> costumerRepo = new CostumerRepository(ctx);
            IMainRepository<Product> productRepo = new ProductRepository(ctx);
            IMainRepository<Purchase> purchaseRepo = new PurchaseRepository(ctx);
            IMainRepository<Country> countryRepo = new CountryRepository(ctx);

            

            Console.ReadLine();
        }
    }
}
