﻿using GuitarSales.Logic.ILogic;
using GuitarSales.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GuitarSales.Endpoint.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CostumerController : ControllerBase
    {
        IAdminLogic adminLogic;
        IReadLogic readLogic;

        public CostumerController(IAdminLogic adminLogic, IReadLogic readLogic)
        {
            this.adminLogic = adminLogic;
            this.readLogic = readLogic;
        }

        [HttpGet]
        public IEnumerable<Costumer> ReadAll()
        {
            return this.readLogic.GetAllCostumers();
        }

        [HttpGet("{id}")]
        public Costumer Read(int id)
        {
            return this.readLogic.GetOneCostumer(id);
        }

        [HttpPost]
        public void Insert([FromBody] Costumer value)
        {
            this.adminLogic.InsertCostumer(value);        
        }

        [HttpPut]
        public void Put([FromBody] Costumer value)
        {
            this.adminLogic.UpdateCostumer(value);
        }

        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            this.adminLogic.DeleteCostumer(readLogic.GetOneCostumer(id));
        }
    }
}
