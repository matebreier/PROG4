﻿using GuitarSales.Logic.ILogic;
using GuitarSales.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GuitarSales.Endpoint.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        IAdminLogic adminLogic;
        IReadLogic readLogic;

        public ProductController(IAdminLogic adminLogic, IReadLogic readLogic)
        {
            this.adminLogic = adminLogic;
            this.readLogic = readLogic;
        }

        [HttpGet]
        public IEnumerable<Product> ReadAll()
        {
            return this.readLogic.GetAllProducts();
        }

        [HttpGet("{id}")]
        public Product Read(int id)
        {
            return this.readLogic.GetOneProduct(id);
        }

        [HttpPost]
        public void Insert([FromBody] Product value)
        {
            this.adminLogic.InsertProduct(value);
        }

        [HttpPut]
        public void Update([FromBody] Product value)
        {
            this.adminLogic.UpdateProduct(value);
        }

        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            this.adminLogic.DeleteProduct(readLogic.GetOneProduct(id));
        }
    }
}
