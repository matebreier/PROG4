﻿using GuitarSales.Logic.ILogic;
using GuitarSales.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GuitarSales.Endpoint.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CountryController : ControllerBase
    {
        IAdminLogic adminLogic;
        IReadLogic readLogic;

        public CountryController(IAdminLogic adminLogic, IReadLogic readLogic)
        {
            this.adminLogic = adminLogic;
            this.readLogic = readLogic;
        }

        [HttpGet]
        public IEnumerable<Country> ReadAll()
        {
            return this.readLogic.GetAllCountry();
        }

        [HttpGet("{id}")]
        public Country Get(int id)
        {
            return this.readLogic.GetOneCountry(id);
        }

        [HttpPost]
        public void Insert([FromBody] Country value)
        {
            this.adminLogic.InsertCountry(value);
        }

        [HttpPut]
        public void Update([FromBody] Country value)
        {
            this.adminLogic.UpdateCountry(value);
        }

        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            this.adminLogic.DeleteCountry(readLogic.GetOneCountry(id));
        }
    }
}
