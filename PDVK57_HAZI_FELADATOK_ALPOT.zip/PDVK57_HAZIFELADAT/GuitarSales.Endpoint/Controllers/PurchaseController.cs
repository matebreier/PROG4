﻿using GuitarSales.Logic.ILogic;
using GuitarSales.Logic.Logic;
using GuitarSales.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GuitarSales.Endpoint.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class PurchaseController : ControllerBase
    {
        IAdminLogic adminLogic;
        IReadLogic readLogic;
        IReportLogic reportLogic;

        public PurchaseController(IAdminLogic adminLogic, IReadLogic readLogic, IReportLogic reportLogic)
        {
            this.adminLogic = adminLogic;
            this.readLogic = readLogic;
            this.reportLogic = reportLogic;
        }

        [HttpGet]
        public IEnumerable<Purchase> ReadAll()
        {
            return this.readLogic.GetAllPurchases();
        }

        [HttpGet("{id}")]
        public Purchase Read(int id)
        {
            return this.readLogic.GetOnePurchase(id);
        }

        [HttpPost]
        public void Insert([FromBody] Purchase value)
        {
            this.adminLogic.InsertPurchase(value);
        }

        [HttpPut]
        public void Update([FromBody] Purchase value)
        {
            this.adminLogic.UpdatePurchase(value);
        }

        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            this.adminLogic.DeletePurchase(readLogic.GetOnePurchase(id));
        }

        [HttpGet("[action]")]
        public IList<CountPurchasesPerCustomer> GetPurchaseCountPerCostumer()
        {
            return this.reportLogic.GetPurchasesPerCustomer();
        }
    }
}
