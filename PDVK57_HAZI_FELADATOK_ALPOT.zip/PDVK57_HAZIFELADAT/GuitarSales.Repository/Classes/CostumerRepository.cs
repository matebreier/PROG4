﻿using GuitarSales.Models;
using GuitarSales.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuitarSales.Repository.Classes
{
    public class CostumerRepository : MainRepository<Costumer>, ICostumerRepository
    {
        public CostumerRepository(DataBaseContext ctx) : base(ctx)
        {
        }

        public override Costumer GetOne(int id)
        {
            return this.GetAll().SingleOrDefault(costumer => costumer.Id == id);
        }

        public override void Update(Costumer costumer)
        {
            var old = this.GetOne((int)costumer.Id);
            if (old == null)
            {
                throw new ArgumentException("Item is not exist..");
            }

            foreach (var prop in old.GetType().GetProperties())
            {
                if (prop.GetAccessors().FirstOrDefault(t => t.IsVirtual) == null)
                {
                    prop.SetValue(old, prop.GetValue(costumer));
                }
            }

            this.ctx.SaveChanges();
        }
    }
}
