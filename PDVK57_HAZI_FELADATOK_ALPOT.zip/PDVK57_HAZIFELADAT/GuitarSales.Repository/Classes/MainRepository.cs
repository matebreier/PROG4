﻿using GuitarSales.Models;
using GuitarSales.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuitarSales.Repository.Classes
{
    public abstract class MainRepository<T> : IMainRepository<T> where T : class
    {
        private protected DataBaseContext ctx;

        public MainRepository(DataBaseContext ctx)
        {
            this.ctx = ctx;
        }


        public IQueryable<T> GetAll()
        {
            return this.ctx.Set<T>();
        }

        public abstract T GetOne(int id);


        public void Insert(T entity)
        {
            this.ctx.Set<T>().Add(entity);
            this.ctx.SaveChanges();
        }

        public void Delete(T entity)
        {
            this.ctx.Set<T>().Remove(entity);
            this.ctx.SaveChanges();
        }

        public abstract void Update(T item);
    }
}
