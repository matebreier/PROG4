﻿using GuitarSales.Models;
using GuitarSales.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuitarSales.Repository.Classes
{
    public class ProductRepository : MainRepository<Product>, IProductRepository
    {
        public ProductRepository(DataBaseContext ctx) : base(ctx)
        {

        }

        public override Product GetOne(int id)
        {
            return this.GetAll().SingleOrDefault(product => product.Id == id);
        }

        public override void Update(Product product)
        {
            var old = this.GetOne((int)product.Id);
            if (old == null)
            {
                throw new ArgumentException("Item is not exist..");
            }

            foreach (var prop in old.GetType().GetProperties())
            {
                if (prop.GetAccessors().FirstOrDefault(t => t.IsVirtual) == null)
                {
                    prop.SetValue(old, prop.GetValue(product));
                }
            }

            this.ctx.SaveChanges();
        }
    }
}
