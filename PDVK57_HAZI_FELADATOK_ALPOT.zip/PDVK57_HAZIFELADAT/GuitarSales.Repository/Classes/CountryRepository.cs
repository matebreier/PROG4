﻿using GuitarSales.Models;
using GuitarSales.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuitarSales.Repository.Classes
{
    public class CountryRepository : MainRepository<Country>, ICountryRepository
    {
        public CountryRepository(DataBaseContext ctx) : base(ctx)
        {

        }

        public override Country GetOne(int id)
        {
            return this.GetAll().SingleOrDefault(country => country.Id == id);
        }

        public override void Update(Country country)
        {
            var old = this.GetOne((int)country.Id);
            if (old == null)
            {
                throw new ArgumentException("Item is not exist..");
            }

            foreach (var prop in old.GetType().GetProperties())
            {
                if (prop.GetAccessors().FirstOrDefault(t => t.IsVirtual) == null)
                {
                    prop.SetValue(old, prop.GetValue(country));
                }
            }

            this.ctx.SaveChanges();
        }
    }
}
