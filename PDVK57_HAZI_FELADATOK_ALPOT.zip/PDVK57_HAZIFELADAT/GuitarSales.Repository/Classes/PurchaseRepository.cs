﻿using GuitarSales.Models;
using GuitarSales.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuitarSales.Repository.Classes
{
    public class PurchaseRepository : MainRepository<Purchase>, IPurchaseRepository
    {
        public PurchaseRepository(DataBaseContext ctx) : base(ctx)
        {

        }

        public override Purchase GetOne(int id)
        {
            return this.GetAll().SingleOrDefault(purchase => purchase.Id == id);
        }

        public override void Update(Purchase purchase)
        {
            var old = this.GetOne((int)purchase.Id);
            if (old == null)
            {
                throw new ArgumentException("Item is not exist..");
            }

            foreach (var prop in old.GetType().GetProperties())
            {
                if (prop.GetAccessors().FirstOrDefault(t => t.IsVirtual) == null)
                {
                    prop.SetValue(old, prop.GetValue(purchase));
                }
            }

            this.ctx.SaveChanges();
        }
    }
}
