﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace GuitarSales.Models
{
    [Table("PRODUCTS")]
    public class Product
    {
        public Product()
        {
            this.Purchases = new HashSet<Purchase>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public int Price { get; set; }

        [Required]
        [ForeignKey(nameof(Country))]
        public int CountryId { get; set; }

        [Required]
        public int Rating { get; set; }

        public string Brand { get; set; }

        [NotMapped]
        [JsonIgnore]
        public virtual Country Country { get; set; }

        [NotMapped]
        [JsonIgnore]
        public virtual ICollection<Purchase> Purchases { get; }

        public override string ToString()
        {
            return $"Id: {this.Id} | Name: {this.Name} | Price: {this.Price} | CountryId: {this.CountryId} | Brand: {this.Brand}";
        }

        public override bool Equals(object obj)
        {
            if (obj is Product)
            {
                Product other = obj as Product;
                return this.Id == other.Id &&
                    this.Name == other.Name &&
                    this.Price == other.Price &&
                    this.CountryId == other.CountryId;
            }

            return false;
        }

        public override int GetHashCode()
        {
            return this.Id;
        }
    }
}
