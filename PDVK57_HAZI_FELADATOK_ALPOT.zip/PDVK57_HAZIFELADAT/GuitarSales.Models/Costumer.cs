﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace GuitarSales.Models
{
    [Table("COSTUMERS")]
    public class Costumer
    {
        public Costumer()
        {
            this.Purchases = new HashSet<Purchase>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Email { get; set; }

        [ForeignKey(nameof(Country))]
        public int CountryId { get; set; }

        [Required]
        public int GivenRating { get; set; }

        [NotMapped]
        [JsonIgnore]
        public virtual Country Country { get; set; }

        [NotMapped]
        [JsonIgnore]
        public virtual ICollection<Purchase> Purchases { get; }

        public override string ToString()
        {
            return $"Id: {this.Id} | Name: {this.Name} | Email: {this.Email} | CountryId: {this.CountryId}";
        }

        public override bool Equals(object obj)
        {
            if (obj is Costumer)
            {
                Costumer other = obj as Costumer;
                return this.Id == other.Id &&
                    this.Name == other.Name &&
                    this.Email == other.Email &&
                    this.CountryId == other.CountryId;
            }

            return false;
        }

        public override int GetHashCode()
        {
            return this.Id;
        }
    }
}
