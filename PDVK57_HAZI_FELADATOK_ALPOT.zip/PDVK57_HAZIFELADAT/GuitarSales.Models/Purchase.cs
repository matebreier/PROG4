﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuitarSales.Models
{
    [Table("PURCHASES")]
    public class Purchase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [ForeignKey(nameof(Costumer))]
        public int CostumerId { get; set; }

        [ForeignKey(nameof(Product))]
        public int ProductId { get; set; }

        public DateTime PurchaseDate { get; set; }

        [Required]
        public int Quantity { get; set; }

        public int ServiceRating { get; set; }

        [NotMapped]
        public virtual Costumer Costumer { get; set; }

        [NotMapped]
        public virtual Product Product { get; set; }

        public override string ToString()
        {
            return $"Id: {this.Id} | ProductID: {this.ProductId} | CostumerID: {this.CostumerId} | PurchaseDate: {this.PurchaseDate} | Quantity: {this.Quantity}";
        }

        public override bool Equals(object obj)
        {
            if (obj is Purchase)
            {
                Purchase other = obj as Purchase;
                return this.Id == other.Id &&
                    this.ProductId == other.ProductId &&
                    this.CostumerId == other.CostumerId &&
                    this.PurchaseDate == other.PurchaseDate &&
                    this.Quantity == other.Quantity;
            }

            return false;
        }

        public override int GetHashCode()
        {
            return this.Id;
        }
    }
}
