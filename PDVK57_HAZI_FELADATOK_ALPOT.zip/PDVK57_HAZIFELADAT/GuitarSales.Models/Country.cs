﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace GuitarSales.Models
{
    [Table("COUNTRIES")]
    public class Country
    {
        public Country()
        {
            this.Costumers = new HashSet<Costumer>();
            this.Products = new HashSet<Product>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Capital { get; set; }

        [Required]
        public int NumberOfShops { get; set; }

        [NotMapped]
        public virtual ICollection<Costumer> Costumers { get; }

        [NotMapped]
        [JsonIgnore]
        public virtual ICollection<Product> Products { get; }

        public override string ToString()
        {
            return $"Id: {this.Id} | Name: {this.Name} | Capital: {this.Capital} | NumberOfShops: {this.NumberOfShops}";
        }

        public override bool Equals(object obj)
        {
            if (obj is Country)
            {
                Country other = obj as Country;
                return this.Id == other.Id &&
                    this.Name == other.Name &&
                    this.Capital == other.Capital &&
                    this.NumberOfShops == other.NumberOfShops;
            }

            return false;
        }

        public override int GetHashCode()
        {
            return this.Id;
        }
    }
}
