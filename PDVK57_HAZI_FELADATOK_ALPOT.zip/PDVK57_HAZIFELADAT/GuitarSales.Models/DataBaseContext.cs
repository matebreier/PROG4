﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuitarSales.Models
{
    public class DataBaseContext : DbContext
    {
        public DataBaseContext()
        {
            this.Database.EnsureCreated();
        }

        public DataBaseContext(DbContextOptions<DataBaseContext> options)
                   : base(options)
        {
        }

        public virtual DbSet<Costumer> Costumers { get; set; }

        public virtual DbSet<Country> Countries { get; set; }

        public virtual DbSet<Product> Products { get; set; }

        public virtual DbSet<Purchase> Purchases { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder
                    .UseLazyLoadingProxies()
                    .UseInMemoryDatabase("guitar");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            Country hungary = new Country() { Id = 1, Name = "Hungary", Capital = "Budapest", NumberOfShops = 20 };
            Country serbia = new Country() { Id = 2, Name = "Serbia", Capital = "Belgrade", NumberOfShops = 25 };
            Country ukraine = new Country() { Id = 3, Name = "Ukraine", Capital = "Kyiv", NumberOfShops = 50 };
            Country austria = new Country() { Id = 4, Name = "Austria", Capital = "Wien", NumberOfShops = 30 };
            Country slovakia = new Country() { Id = 5, Name = "Slovakia", Capital = "Bratislava", NumberOfShops = 15 };
            Country slovenia = new Country() { Id = 6, Name = "Slovenia", Capital = "Ljubljana", NumberOfShops = 10 };
            Country croatia = new Country() { Id = 7, Name = "Croatia", Capital = "Zagreb", NumberOfShops = 20 };
            Country romania = new Country() { Id = 8, Name = "Romania", Capital = "Bucharest", NumberOfShops = 40 };

            Product fenderLow = new Product() { Id = 1, Name = "Fender-LOW", Price = 500, CountryId = 1, Brand = "Fender", Rating = 5 };
            Product fenderPremium = new Product() { Id = 2, Name = "Fender-PREMIUM", Price = 7000, CountryId = 1, Brand = "Fender", Rating = 3 };
            Product jacksonLow = new Product() { Id = 3, Name = "Jackson-LOW", Price = 250, CountryId = 2, Brand = "Jackson", Rating = 5 };
            Product jacksonPremium = new Product() { Id = 4, Name = "Jackson-PREMIUM", Price = 3000, CountryId = 2, Brand = "Jackson", Rating = 4 };
            Product solarLow = new Product() { Id = 5, Name = "Solar-LOW", Price = 300, CountryId = 3, Brand = "Solar", Rating = 5 };
            Product solarPremium = new Product() { Id = 6, Name = "Solar-PREMIUM", Price = 4000, CountryId = 3, Brand = "Solar", Rating = 4 };
            Product harleyBentonLow = new Product() { Id = 7, Name = "Harley Benton-LOW", Price = 200, CountryId = 4, Brand = "Harley Benton", Rating = 2 };
            Product harleyBentonPremium = new Product() { Id = 8, Name = "Harley Benton-PREMIUM", Price = 2500, CountryId = 4, Brand = "Harley Benton", Rating = 3 };
            Product prsLow = new Product() { Id = 9, Name = "PRS-LOW", Price = 650, CountryId = 5, Brand = "PRS", Rating = 5 };
            Product prsPremium = new Product() { Id = 10, Name = "PRS-PREMIUM", Price = 8000, CountryId = 5, Brand = "PRS", Rating = 3 };
            Product yamahaLow = new Product() { Id = 11, Name = "Yamaha-LOW", Price = 150, CountryId = 6, Brand = "Yamaha", Rating = 5 };
            Product yamahaPremium = new Product() { Id = 12, Name = "Yamaha-PREMIUM", Price = 2500, CountryId = 6, Brand = "Yamaha", Rating = 4 };
            Product washburnLow = new Product() { Id = 13, Name = "Washburn-LOW", Price = 400, CountryId = 7, Brand = "Washburn", Rating = 5 };
            Product washburnPremium = new Product() { Id = 14, Name = "Washburn-PREMIUM", Price = 6000, CountryId = 7, Brand = "Washburn", Rating = 4 };
            Product gibsonLow = new Product() { Id = 15, Name = "Gibson-LOW", Price = 1000, CountryId = 8, Brand = "Gibson", Rating = 2 };
            Product gibsonPremium = new Product() { Id = 16, Name = "Gibson-PREMIUM", Price = 10000, CountryId = 8, Brand = "Gibson", Rating = 3 };

            Costumer gipszJakab = new Costumer() { Id = 1, Name = "Gipsz Jakab", Email = "gipszjakab@gmail.com", CountryId = 1, GivenRating = 5 };
            Costumer kovacsPeter = new Costumer() { Id = 2, Name = "Kovacs Peter", Email = "kovacspeter@gmail.com", CountryId = 2, GivenRating = 4 };
            Costumer molnarBela = new Costumer() { Id = 3, Name = "Molnar Bela", Email = "molnarbela@gmail.com", CountryId = 3, GivenRating = 3 };
            Costumer aranyosJozsef = new Costumer() { Id = 4, Name = "Aranyos Jozsef", Email = "aranyosjozsef@gmail.com", CountryId = 2, GivenRating = 2 };
            Costumer erosAntal = new Costumer() { Id = 5, Name = "Eros Antal", Email = "erosAntal@gmail.com", CountryId = 1, GivenRating = 3 };
            Costumer hizosAndras = new Costumer() { Id = 6, Name = "Hizos Andras", Email = "hizosandras@gmail.com", CountryId = 3, GivenRating = 4 };
            Costumer kisPetike = new Costumer() { Id = 7, Name = "Kis Petike", Email = "kispetike@gmail.com", CountryId = 1, GivenRating = 5 };
            Costumer nagyCsongor = new Costumer() { Id = 8, Name = "Nagy Csongor", Email = "nagycsongor@gmail.com", CountryId = 2, GivenRating = 3 };
            Costumer angolBalint = new Costumer() { Id = 9, Name = "Angol Balint", Email = "angolbalint@gmail.com", CountryId = 3, GivenRating = 4 };

            Purchase first = new Purchase() { Id = 1, CostumerId = 1, ProductId = 1, PurchaseDate = new DateTime(2015, 04, 01), Quantity = 1, ServiceRating = 5 };
            Purchase second = new Purchase() { Id = 2, CostumerId = 3, ProductId = 6, PurchaseDate = new DateTime(2015, 04, 15), Quantity = 2, ServiceRating = 4 };
            Purchase third = new Purchase() { Id = 3, CostumerId = 5, ProductId = 3, PurchaseDate = new DateTime(2015, 04, 28), Quantity = 3, ServiceRating = 3 };
            Purchase forth = new Purchase() { Id = 4, CostumerId = 2, ProductId = 11, PurchaseDate = new DateTime(2015, 04, 29), Quantity = 4, ServiceRating = 2 };
            Purchase fifth = new Purchase() { Id = 5, CostumerId = 7, ProductId = 2, PurchaseDate = new DateTime(2015, 05, 02), Quantity = 5, ServiceRating = 1 };
            Purchase sixth = new Purchase() { Id = 6, CostumerId = 8, ProductId = 4, PurchaseDate = new DateTime(2015, 05, 07), Quantity = 2, ServiceRating = 2 };
            Purchase seventh = new Purchase() { Id = 7, CostumerId = 4, ProductId = 14, PurchaseDate = new DateTime(2015, 05, 17), Quantity = 4, ServiceRating = 3 };
            Purchase eight = new Purchase() { Id = 8, CostumerId = 6, ProductId = 12, PurchaseDate = new DateTime(2015, 05, 26), Quantity = 3, ServiceRating = 4 };
            Purchase ninth = new Purchase() { Id = 9, CostumerId = 1, ProductId = 1, PurchaseDate = new DateTime(2015, 05, 29), Quantity = 5, ServiceRating = 5 };
            Purchase tenth = new Purchase() { Id = 10, CostumerId = 2, ProductId = 2, PurchaseDate = new DateTime(2015, 06, 03), Quantity = 1, ServiceRating = 4 };
            Purchase eleventh = new Purchase() { Id = 11, CostumerId = 3, ProductId = 3, PurchaseDate = new DateTime(2015, 06, 08), Quantity = 2, ServiceRating = 4 };
            Purchase twelveth = new Purchase() { Id = 12, CostumerId = 4, ProductId = 4, PurchaseDate = new DateTime(2015, 06, 12), Quantity = 6, ServiceRating = 3 };
            Purchase thirtheenth = new Purchase() { Id = 13, CostumerId = 5, ProductId = 1, PurchaseDate = new DateTime(2015, 06, 25), Quantity = 8, ServiceRating = 2 };
            Purchase fourthteenth = new Purchase() { Id = 14, CostumerId = 6, ProductId = 5, PurchaseDate = new DateTime(2015, 07, 01), Quantity = 7, ServiceRating = 1 };
            Purchase fifthteenth = new Purchase() { Id = 15, CostumerId = 7, ProductId = 6, PurchaseDate = new DateTime(2015, 07, 09), Quantity = 3, ServiceRating = 2 };
            Purchase sixteenth = new Purchase() { Id = 16, CostumerId = 8, ProductId = 1, PurchaseDate = new DateTime(2015, 07, 16), Quantity = 5, ServiceRating = 3 };
            Purchase seventeenth = new Purchase() { Id = 17, CostumerId = 2, ProductId = 10, PurchaseDate = new DateTime(2015, 07, 28), Quantity = 2, ServiceRating = 4 };
            Purchase eighteenth = new Purchase() { Id = 18, CostumerId = 3, ProductId = 13, PurchaseDate = new DateTime(2015, 08, 03), Quantity = 1, ServiceRating = 5 };
            Purchase ninteenth = new Purchase() { Id = 19, CostumerId = 4, ProductId = 9, PurchaseDate = new DateTime(2015, 08, 12), Quantity = 2, ServiceRating = 5 };

            modelBuilder.Entity<Purchase>(entity =>
            {
                entity.HasOne(purchase => purchase.Costumer).
                    WithMany(costumers => costumers.Purchases).
                    HasForeignKey(purchases => purchases.CostumerId).
                    OnDelete(DeleteBehavior.Cascade);
            });
            modelBuilder.Entity<Purchase>(entity =>
            {
                entity.HasOne(purchase => purchase.Product).
                    WithMany(products => products.Purchases).
                    HasForeignKey(purchases => purchases.ProductId).
                    OnDelete(DeleteBehavior.Cascade);
            });
            modelBuilder.Entity<Costumer>(entity =>
            {
                entity.HasOne(costumer => costumer.Country).
                    WithMany(countries => countries.Costumers).
                    HasForeignKey(costumer => costumer.CountryId).
                    OnDelete(DeleteBehavior.Cascade);
            });
            modelBuilder.Entity<Product>(entity =>
            {
                entity.HasOne(product => product.Country).
                    WithMany(countries => countries.Products).
                    HasForeignKey(product => product.CountryId).
                    OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<Country>().HasData(romania, hungary, slovakia, slovenia, croatia, austria, ukraine, serbia);
            modelBuilder.Entity<Product>().HasData(fenderLow, fenderPremium, prsLow, prsPremium, gibsonLow, gibsonPremium, jacksonLow, jacksonPremium, solarLow, solarPremium, yamahaLow, yamahaPremium, washburnPremium, washburnLow, harleyBentonLow, harleyBentonPremium);
            modelBuilder.Entity<Costumer>().HasData(gipszJakab, kovacsPeter, molnarBela, aranyosJozsef, erosAntal, hizosAndras, kisPetike, nagyCsongor, angolBalint);
            modelBuilder.Entity<Purchase>().HasData(first, second, third, forth, fifth, seventh, eight, ninth, tenth, eleventh, twelveth, thirtheenth, fourthteenth, fifthteenth, sixteenth, seventeenth, eighteenth, ninteenth);
        }
    }
}
