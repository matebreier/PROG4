﻿let costumers = [];
let connection = null;

let purchasecount = [];

let costumerIdToUpdate = -1;
getdata();
getcountdata();

async function getdata() {
    await fetch('http://localhost:7114/Costumer')
        .then(x => x.json())
        .then(y => {
            costumers = y;
            display();
        });
}

async function getcountdata() {
    await fetch('http://localhost:7114/Purchase/GetPurchaseCountPerCostumer')
        .then(x => x.json())
        .then(y => {
            purchasecount = y;
            countdisplay();
        });
}

function countdisplay() {
    document.getElementById('purchasecount').innerHTML = "";
    purchasecount.forEach(t => {
        document.getElementById('purchasecount').innerHTML +=
            "<tr><td>" + t.costumerName + "</td><td>"
            + t.purchasesCounter + "</td></tr>";
    });
}

function display() {
    document.getElementById('resultarea').innerHTML = "";
    costumers.forEach(t => {
        document.getElementById('resultarea').innerHTML +=
            "<tr><td>" + t.id + "</td><td>"
            + t.name + "</td><td>"
            + t.email + "</td><td>"
            + t.countryId + "</td><td>"
            + t.givenRating + "</td><td>"
            + `<button type="button" onclick="remove(${t.id})">Delete</button>`
            + `<button type="button" onclick="showupdate(${t.id})">Update</button>`
            + "</td></tr>";
    });
}

function create() {
    let costumerName = document.getElementById('name').value;
    let costumerEmail = document.getElementById('email').value;
    let costumerCountryId = document.getElementById('countryid').value;
    let costumerGivenRating = document.getElementById('givenrating').value;
    fetch('http://localhost:7114/Costumer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', },
        body: JSON.stringify(
            {
                name: costumerName,
                email: costumerEmail,
                countryid: costumerCountryId,
                givenrating: costumerGivenRating
            }),
    })
        .then(response => response)
        .then(data => {
            console.log('Success:', data);
            getdata();
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    display();
}

function remove(id) {
    fetch('http://localhost:7114/Costumer/' + id, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json', },
        body: null
    })
        .then(response => response)
        .then(data => {
            console.log('Success:', data);
            getdata();
        })
        .catch((error) => { console.error('Error:', error); });
}

function showupdate(id) {
    document.getElementById('nametoupdate').value = costumers.find(t => t['id'] == id)['name'];
    document.getElementById('emailtoupdate').value = costumers.find(t => t['id'] == id)['email'];
    document.getElementById('countryidtoupdate').value = costumers.find(t => t['id'] == id)['countryId'];
    document.getElementById('givenratingtoupdate').value = costumers.find(t => t['id'] == id)['givenRating'];

    document.getElementById('updateformdiv').style.display = 'flex';
    costumerIdToUpdate = id;
}

function update() {
    document.getElementById('updateformdiv').style.display = 'none';
    let costumerName = document.getElementById('nametoupdate').value;
    let costumerEmail = document.getElementById('emailtoupdate').value;
    let costumerCountryId = document.getElementById('countryidtoupdate').value;
    let costumerGivenRating = document.getElementById('givenratingtoupdate').value;

    fetch('http://localhost:7114/Costumer', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', },
        body: JSON.stringify(
            {
                name: costumerName,
                email: costumerEmail,
                countryid: costumerCountryId,
                givenrating: costumerGivenRating,
                id: costumerIdToUpdate
            }),
    })
        .then(response => response)
        .then(data => {
            console.log('Success:', data);
            getdata();
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    display();
}