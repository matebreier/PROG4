﻿using GuitarSales.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace GuitarSales.WpfClient
{
    public class CountryWindowViewModel : ObservableRecipient
    {
        public RestCollection<Country> Countries { get; set; }

        public ICommand OpenMainWindowCommand { get; set; }
        public ICommand OpenProductWindowCommand { get; set; }
        public ICommand OpenPurchaseWindowCommand { get; set; }

        public ICommand CreateCountryCommand { get; set; }
        public ICommand UpdateCountryCommand { get; set; }
        public ICommand DeleteCountryCommand { get; set; }       

        private Country newCountry;

        public Country NewCountry
        {
            get { return newCountry; }
            set
            {
                SetProperty(ref newCountry, value);
                (CreateCountryCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdateCountryCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        private Country selectedCountry;

        public Country SelectedCountry
        {
            get { return selectedCountry; }
            set
            {
                if (value != null)
                {
                    selectedCountry = new Country()
                    {
                        Id = value.Id,
                        Name = value.Name,
                        Capital = value.Capital,
                        NumberOfShops = value.NumberOfShops
                    };
                    OnPropertyChanged();
                    (DeleteCountryCommand as RelayCommand).NotifyCanExecuteChanged();
                    (UpdateCountryCommand as RelayCommand).NotifyCanExecuteChanged();
                }
            }
        }

        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }

        public CountryWindowViewModel()
        {
            if (!IsInDesignMode)
            {
                Countries = new RestCollection<Country>("http://localhost:7114/", "Country");
                CreateCountryCommand = new RelayCommand(() =>
                {
                    Countries.Add(newCountry);
                });

                UpdateCountryCommand = new RelayCommand(() =>
                {
                    Countries.Update(selectedCountry);
                },
                () =>
                {
                    return SelectedCountry != null;
                });


                DeleteCountryCommand = new RelayCommand(() =>
                {
                    Countries.Delete(selectedCountry.Id);
                },
                () =>
                {
                    return SelectedCountry != null;
                });
            }

            newCountry = new Country();
            newCountry.Name = "Add Name";
            newCountry.Capital = "Add Capital";
            newCountry.NumberOfShops = 1;

            OpenMainWindowCommand = new RelayCommand(SwitchToMainWindow);
            OpenProductWindowCommand = new RelayCommand(SwitchToProductWindow);
            OpenPurchaseWindowCommand = new RelayCommand(SwitchToPurchaseWindow);
        }

        public void SwitchToMainWindow()
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
        }

        public void SwitchToProductWindow()
        {
            ProductWindow productWindow = new ProductWindow();
            productWindow.Show();
        }

        public void SwitchToPurchaseWindow()
        {
            PurchaseWindow purchaseWindow = new PurchaseWindow();
            purchaseWindow.Show();
        }
    }
}
