﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace GuitarSales.WpfClient
{
    class ValidateGivenRating : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            int validateValue;
            try
            {
                validateValue = Convert.ToInt32(value);
            }
            catch(FormatException)
            {
                validateValue = 1;
            }

            if (validateValue <= 5 && validateValue >= 1)
            {
                return ValidationResult.ValidResult;
            }

            return new ValidationResult(false, "GivenRating must be between 1-5!");
        }
    }
}
