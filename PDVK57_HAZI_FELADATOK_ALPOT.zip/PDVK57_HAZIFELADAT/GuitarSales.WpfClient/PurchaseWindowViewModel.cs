﻿using GuitarSales.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace GuitarSales.WpfClient
{
    public class PurchaseWindowViewModel : ObservableRecipient
    {
        public RestCollection<Purchase> Purchases { get; set; }

        public ICommand OpenMainWindowCommand { get; set; }
        public ICommand OpenProductWindowCommand { get; set; }
        public ICommand OpenCountryWindowCommand { get; set; }

        public ICommand CreatePurchaseCommand { get; set; }
        public ICommand UpdatePurchaseCommand { get; set; }
        public ICommand DeletePurchaseCommand { get; set; }      

        private Purchase newPurchase;

        public Purchase NewPurchase
        {
            get { return newPurchase; }
            set
            {
                SetProperty(ref newPurchase, value);
                (CreatePurchaseCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdatePurchaseCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        private Purchase selectedPurchase;

        public Purchase SelectedPurchase
        {
            get { return selectedPurchase; }
            set
            {
                if (value != null)
                {
                    selectedPurchase = new Purchase()
                    {
                        Id = value.Id,
                        Quantity = value.Quantity,
                        CostumerId = value.CostumerId,
                        ProductId = value.ProductId,
                        ServiceRating = value.ServiceRating,
                        Costumer = value.Costumer,
                        Product = value.Product,
                        PurchaseDate = value.PurchaseDate

                    };
                    OnPropertyChanged();
                    (DeletePurchaseCommand as RelayCommand).NotifyCanExecuteChanged();
                    (UpdatePurchaseCommand as RelayCommand).NotifyCanExecuteChanged();
                }
            }
        }
        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }

        public PurchaseWindowViewModel()
        {
            if (!IsInDesignMode)
            {
                Purchases = new RestCollection<Purchase>("http://localhost:7114/", "Purchase");
                CreatePurchaseCommand = new RelayCommand(() =>
                {
                    Purchases.Add(newPurchase);
                });

                UpdatePurchaseCommand = new RelayCommand(() =>
                {
                    Purchases.Update(selectedPurchase);
                },
                () =>
                {
                    return SelectedPurchase != null;
                });


                DeletePurchaseCommand = new RelayCommand(() =>
                {
                    Purchases.Delete(selectedPurchase.Id);
                },
                () =>
                {
                    return SelectedPurchase != null;
                });
            }

            newPurchase = new Purchase();
            newPurchase.Quantity = 1;
            newPurchase.CostumerId = 1;
            newPurchase.ProductId = 1;
            newPurchase.ServiceRating = 1;

            OpenMainWindowCommand = new RelayCommand(SwitchToMainWindow);
            OpenProductWindowCommand = new RelayCommand(SwitchToProductWindow);
            OpenCountryWindowCommand = new RelayCommand(SwitchToCountryWindow);

        }

        public void SwitchToMainWindow()
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();

        }

        public void SwitchToProductWindow()
        {
            ProductWindow productWindow = new ProductWindow();
            productWindow.Show();
        }

        public void SwitchToCountryWindow()
        {
            CountryWindow countryWindow = new CountryWindow();
            countryWindow.Show();
        }
    }
}
