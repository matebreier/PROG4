﻿using GuitarSales.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace GuitarSales.WpfClient
{
    public class ProductWindowViewModel : ObservableRecipient
    {
        public RestCollection<Product> Products { get; set; }

        public ICommand OpenMainWindowCommand { get; set; }
        public ICommand OpenCountryWindowCommand { get; set; }
        public ICommand OpenPurchaseWindowCommand { get; set; }
        

        public ICommand CreateProductCommand { get; set; }
        public ICommand UpdateProductCommand { get; set; }
        public ICommand DeleteProductCommand { get; set; }      

        private Product newProduct;

        public Product NewProduct
        {
            get { return newProduct; }
            set
            {
                SetProperty(ref newProduct, value);
                (CreateProductCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdateProductCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        private Product selectedProduct;

        public Product SelectedProduct
        {
            get { return selectedProduct; }
            set
            {
                if (value != null)
                {
                    selectedProduct = new Product()
                    {
                        Id = value.Id,
                        Name = value.Name,
                        Brand = value.Brand,
                        Price = value.Price,
                        Rating = value.Rating,
                        CountryId = value.CountryId

                    };
                    OnPropertyChanged();
                    (DeleteProductCommand as RelayCommand).NotifyCanExecuteChanged();
                    (UpdateProductCommand as RelayCommand).NotifyCanExecuteChanged();
                }
            }
        }

        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }

        public ProductWindowViewModel()
        {
            if (!IsInDesignMode)
            {
                Products = new RestCollection<Product>("http://localhost:7114/", "Product");
                CreateProductCommand = new RelayCommand(() =>
                {
                    Products.Add(newProduct);
                });

                UpdateProductCommand = new RelayCommand(() =>
                {
                    Products.Update(selectedProduct);
                },
                () =>
                {
                    return SelectedProduct != null;
                });


                DeleteProductCommand = new RelayCommand(() =>
                {
                    Products.Delete(selectedProduct.Id);
                },
                () =>
                {
                    return SelectedProduct != null;
                });
            }

            newProduct = new Product();
            newProduct.Name = "Add Name";
            newProduct.Brand = "Add Brand";
            newProduct.Price = 1;
            newProduct.Rating = 1;
            newProduct.CountryId = 1;

            OpenMainWindowCommand = new RelayCommand(SwitchToMainWindow);
            OpenCountryWindowCommand = new RelayCommand(SwitchToCountryWindow);
            OpenPurchaseWindowCommand = new RelayCommand(SwitchToPurchaseWindow);
        }

        public void SwitchToMainWindow()
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
        }

        public void SwitchToCountryWindow()
        {
            CountryWindow countryWindow = new CountryWindow();
            countryWindow.Show();
        }

        public void SwitchToPurchaseWindow()
        {
            PurchaseWindow purchaseWindow = new PurchaseWindow();
            purchaseWindow.Show();
        }
    }
}
