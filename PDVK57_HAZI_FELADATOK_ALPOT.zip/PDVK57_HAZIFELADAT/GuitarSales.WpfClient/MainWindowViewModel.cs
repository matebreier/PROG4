﻿using GuitarSales.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace GuitarSales.WpfClient
{
    public class MainWindowViewModel : ObservableRecipient
    {
        public RestCollection<Costumer> Costumers { get; set; }

        public ICommand CreateCostumerCommand { get; set; }
        public ICommand DeleteCostumerCommand { get; set; }
        public ICommand UpdateCostumerCommand { get; set; }

        public ICommand OpenProductCommand { get; set; }
        public ICommand OpenCountryCommand { get; set; }
        public ICommand OpenPurchaseCommand { get; set; }

        private Costumer newCostumer;

        public Costumer NewCostumer
        {
            get { return newCostumer; }
            set
            {
                SetProperty(ref newCostumer, value);
                (CreateCostumerCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdateCostumerCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        private Costumer selectedCostumer;

        public Costumer SelectedCostumer
        {
            get { return selectedCostumer; }
            set
            {
                if (value != null)
                {
                    selectedCostumer = new Costumer()
                    {
                        Name = value.Name,
                        Id = value.Id,
                        CountryId = value.CountryId,
                        Email = value.Email,
                        GivenRating = value.GivenRating,
                        Country = value.Country
                    };
                }
                OnPropertyChanged();
                (DeleteCostumerCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdateCostumerCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }

        public MainWindowViewModel()
        {
            if (!IsInDesignMode)
            {
                Costumers = new RestCollection<Costumer>("http://localhost:7114/", "Costumer");

                CreateCostumerCommand = new RelayCommand(() =>
                {
                    Costumers.Add(newCostumer);
                });

                UpdateCostumerCommand = new RelayCommand(() =>
                {
                    Costumers.Update(selectedCostumer);
                },
                () =>
                {
                    return SelectedCostumer != null;
                });


                DeleteCostumerCommand = new RelayCommand(() =>
                {
                    Costumers.Delete(selectedCostumer.Id);
                },
                () =>
                {
                    return SelectedCostumer != null;
                });

                OpenProductCommand = new RelayCommand(SwitchToProductWindow);
                OpenCountryCommand = new RelayCommand(SwitchToCountryWindow);
                OpenPurchaseCommand = new RelayCommand(SwitchToPurchaseWindow);
            }

            newCostumer = new Costumer();
            newCostumer.Name = "Add Name";
            newCostumer.Email = "Add Email";
            newCostumer.CountryId = 1;
            newCostumer.GivenRating = 1;
        }

        public void SwitchToProductWindow()
        {
            ProductWindow productWindow = new ProductWindow();
            productWindow.Show();
        }
        public void SwitchToCountryWindow()
        {
            CountryWindow countryWindow = new CountryWindow();
            countryWindow.Show();
        }
        public void SwitchToPurchaseWindow()
        {
            PurchaseWindow purchaseWindow = new PurchaseWindow();
            purchaseWindow.Show();
        }
    }
}
